
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'antholeinik',
  applicationName: 'club-app',
  appUid: 'gVxWZyTGyhNLmG7cWP',
  orgUid: '2b6b9c02-a82e-4a22-aa05-a6c3ac95ca19',
  deploymentUid: '50bfbd5d-1794-4128-b1ac-5fc7d923efef',
  serviceName: 'api-gateway',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'api-gateway-dev-handler', timeout: 6 };

try {
  const userHandler = require('./dist/dist-bundle.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}